from django.apps import AppConfig


class DailyRevenueConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daily_revenue'
