from django.apps import AppConfig


class ManageSubscribersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'manage_subscribers'
