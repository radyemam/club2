from django.apps import AppConfig


class MemberManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'member_management'
